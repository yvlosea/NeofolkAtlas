
import { initRouter } from './router/index.js'
import { initI18n } from './i18n/index.js'

function ensureRoot(){
 if(!document.getElementById('app-root')){
   const el=document.createElement('div')
   el.id='app-root'
   document.body.appendChild(el)
 }
}

document.addEventListener('DOMContentLoaded', ()=>{
 ensureRoot()
 initI18n()
 initRouter()
})
