
const routes={
"/":()=>import("../pages/home.js"),
"/dashboard":()=>import("../pages/dashboard.js"),
"/notes":()=>import("../pages/notes.js"),
"/projects":()=>import("../pages/projects.js"),
"/groups":()=>import("../pages/groups.js"),
"/progress":()=>import("../pages/progress.js"),
"/learn":()=>import("../pages/learn.js"),
"/discovery":()=>import("../pages/discovery.js"),
"/dictionary":()=>import("../pages/dictionary.js"),
"/vision":()=>import("../pages/vision.js"),
"/settings":()=>import("../pages/settings.js"),
"/guild":()=>import("../pages/guild.js")
}

function getPath(){
 return location.hash.replace("#","")||"/"
}

export async function initRouter(){
 async function render(){
  const path=getPath()
  const loader=routes[path]||routes["/"]
  const mod=await loader()
  const root=document.getElementById("app-root")
  root.innerHTML=""
  mod.mount(root)
 }
 window.addEventListener("hashchange",render)
 render()
}
