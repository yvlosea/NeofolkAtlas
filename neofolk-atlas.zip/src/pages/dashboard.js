
export async function mount(root){
 root.innerHTML=`<div style="padding:40px">
 <h1>Coming soon</h1>
 </div>`
}
